const defaultTheme = require('tailwindcss/defaultTheme');
const colors = require('tailwindcss/colors');

/** @type {import('tailwindcss').Config} */
module.exports = {
    content: [
        './vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php',
        './storage/framework/views/*.php',
        './resources/views/**/*.blade.php',
        './resources/js/**/*.jsx',
    ],

    theme: {
        extend: {
            fontFamily: {
                sans: ['Figtree', ...defaultTheme.fontFamily.sans],
            },
            colors: {
                blue: colors.blue,
                green: colors.green,
                purple: colors.purple,
                red: colors.red,
                yellow: colors.yellow,
                pink: colors.pink,
                indigo: colors.indigo,
                teal: colors.teal,
            },
            animation: {
                'rgb-gradient': 'rgb-gradient 10s linear infinite',
            },
            keyframes: {
                'rgb-gradient': {
                    '0%': { backgroundColor: 'rgb(255,0,0)' },
                    '33%': { backgroundColor: 'rgb(0,255,0)' },
                    '66%': { backgroundColor: 'rgb(0,0,255)' },
                    '100%': { backgroundColor: 'rgb(255,0,0)' },
                },
            },
            backgroundImage: {
                'custom1': "url('/images/ROG1.jpg')",
                'custom2': "url('/images/ROG2.jpg')",
            },
        },
    },

    safelist: [
        'from-blue-400', 'to-blue-600', 'text-blue-600', 'bg-blue-600', 'hover:bg-blue-700',
        'from-green-400', 'to-green-600', 'text-green-600', 'bg-green-600', 'hover:bg-green-700',
        'from-purple-400', 'to-purple-600', 'text-purple-600', 'bg-purple-600', 'hover:bg-purple-700',
        'from-red-400', 'to-red-600', 'text-red-600', 'bg-red-600', 'hover:bg-red-700',
        'from-yellow-300', 'to-orange-500',
        'from-cyan-100', 'to-blue-300',
        'from-orange-500', 'to-black',
        'animate-rgb-gradient',
        'from-yellow-400', 'to-yellow-600',
        'from-pink-400', 'to-pink-600',
        'from-indigo-400', 'to-indigo-600',
        'from-teal-400', 'to-teal-600',
        'bg-custom1', 'bg-custom2',
    ],

    plugins: [require('@tailwindcss/forms')],
};
