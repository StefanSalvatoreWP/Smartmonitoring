import React, { useState, useRef } from 'react';
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head } from '@inertiajs/react';
import { QRCodeSVG } from 'qrcode.react';

const defaultProfilePic = "images/DefaultID.png"; // Add this at the top of your component

const IdMaker = ({ auth }) => {
    const [frontInfo, setFrontInfo] = useState({
        cardWidth: 300,
        cardHeight: 420,
        firstName: '',
        lastName: '',
        idNumber: '',
        photo: null,
        signature: null,
        academicTrack: '', // Add this line
    });

    const [backInfo, setBackInfo] = useState({
        name: '',
        address: '',
        telNo: '',
        academicTrack: '',
    });

    const photoRef = useRef(null);
    const signatureRef = useRef(null);

    const handleFrontInputChange = (e) => {
        const { name, value } = e.target;
        setFrontInfo(prev => ({ ...prev, [name]: value }));
    };

    const handleBackInputChange = (e) => {
        const { name, value } = e.target;
        setBackInfo(prev => ({ ...prev, [name]: value }));
        if (name === 'academicTrack') {
            setFrontInfo(prev => ({ ...prev, academicTrack: value }));
        }
    };

    const handleFileUpload = (e, type) => {
        const file = e.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setFrontInfo(prev => ({ ...prev, [type]: reader.result }));
            };
            reader.readAsDataURL(file);
        }
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Here you would typically send the data to your backend
        console.log('Submitting ID info:', { frontInfo, backInfo });
        // You can add API call here to process the ID
    };

    return (
        <AuthenticatedLayout user={auth.user}>
            <Head title="ID Maker" />
            <div className="flex flex-col h-[calc(100vh-64px)]"> {/* Adjust 64px if your header height is different */}
                <div className="flex-grow overflow-hidden">
                    <div className="h-full max-w-7xl mx-auto sm:px-6 lg:px-8">
                        <div className="h-full bg-white overflow-hidden shadow-sm sm:rounded-lg">
                            <div className="h-full p-6 text-gray-900">
                                <h1 className="text-2xl font-semibold mb-6">Create ID</h1>
                                <div className="flex flex-col lg:flex-row gap-6 h-[calc(100%-2rem)]">
                                    <div className="w-full lg:w-[calc(50%-1rem)] overflow-y-auto pr-4">
                                        <h2 className="text-xl font-semibold mb-4">ID Information</h2>
                                        <form onSubmit={handleSubmit} className="space-y-4">
                                            <div className="flex gap-4">
                                                <div className="w-1/2">
                                                    <label htmlFor="cardWidth" className="block text-sm font-medium text-gray-700">Card Width (px)</label>
                                                    <input
                                                        type="number"
                                                        id="cardWidth"
                                                        name="cardWidth"
                                                        value={frontInfo.cardWidth}
                                                        onChange={handleFrontInputChange}
                                                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                        required
                                                    />
                                                </div>
                                                <div className="w-1/2">
                                                    <label htmlFor="cardHeight" className="block text-sm font-medium text-gray-700">Card Height (px)</label>
                                                    <input
                                                        type="number"
                                                        id="cardHeight"
                                                        name="cardHeight"
                                                        value={frontInfo.cardHeight}
                                                        onChange={handleFrontInputChange}
                                                        className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                        required
                                                    />
                                                </div>
                                            </div>
                                            <div>
                                                <label htmlFor="firstName" className="block text-sm font-medium text-gray-700">First Name</label>
                                                <input
                                                    type="text"
                                                    id="firstName"
                                                    name="firstName"
                                                    value={frontInfo.firstName}
                                                    onChange={handleFrontInputChange}
                                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <label htmlFor="lastName" className="block text-sm font-medium text-gray-700">Last Name</label>
                                                <input
                                                    type="text"
                                                    id="lastName"
                                                    name="lastName"
                                                    value={frontInfo.lastName}
                                                    onChange={handleFrontInputChange}
                                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <label htmlFor="idNumber" className="block text-sm font-medium text-gray-700">Enter ID Number</label>
                                                <input
                                                    type="text"
                                                    id="idNumber"
                                                    name="idNumber"
                                                    value={frontInfo.idNumber}
                                                    onChange={handleFrontInputChange}
                                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <label htmlFor="photo" className="block text-sm font-medium text-gray-700">Upload Photo</label>
                                                <input
                                                    type="file"
                                                    id="photo"
                                                    name="photo"
                                                    onChange={(e) => handleFileUpload(e, 'photo')}
                                                    className="mt-1 block w-full"
                                                    accept="image/*"
                                                    ref={photoRef}
                                                />
                                            </div>
                                            <div>
                                                <label htmlFor="signature" className="block text-sm font-medium text-gray-700">Student Signature Photo</label>
                                                <input
                                                    type="file"
                                                    id="signature"
                                                    name="signature"
                                                    onChange={(e) => handleFileUpload(e, 'signature')}
                                                    className="mt-1 block w-full"
                                                    accept="image/*"
                                                    ref={signatureRef}
                                                />
                                            </div>
                                            <h2 className="text-xl font-semibold mb-4 mt-8">Back of ID</h2>
                                            <div>
                                                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
                                                <input
                                                    type="text"
                                                    id="name"
                                                    name="name"
                                                    value={backInfo.name}
                                                    onChange={handleBackInputChange}
                                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <label htmlFor="address" className="block text-sm font-medium text-gray-700">Address</label>
                                                <input
                                                    type="text"
                                                    id="address"
                                                    name="address"
                                                    value={backInfo.address}
                                                    onChange={handleBackInputChange}
                                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <label htmlFor="telNo" className="block text-sm font-medium text-gray-700">Tel No</label>
                                                <input
                                                    type="tel"
                                                    id="telNo"
                                                    name="telNo"
                                                    value={backInfo.telNo}
                                                    onChange={handleBackInputChange}
                                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <label htmlFor="academicTrack" className="block text-sm font-medium text-gray-700">STRANDS IN THE ACADEMIC TRACK</label>
                                                <input
                                                    type="text"
                                                    id="academicTrack"
                                                    name="academicTrack"
                                                    value={backInfo.academicTrack}
                                                    onChange={handleBackInputChange}
                                                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                                                    required
                                                />
                                            </div>
                                            <div>
                                                <button
                                                    type="submit"
                                                    className="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 active:bg-blue-800 focus:outline-none focus:border-blue-800 focus:ring focus:ring-blue-300 disabled:opacity-25 transition"
                                                >
                                                    Create ID
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                    <div className="w-full lg:w-[calc(50%-1rem)] overflow-y-auto pl-4">
                                        <h2 className="text-xl font-semibold mb-4">ID Preview</h2>
                                        <div className="flex flex-col md:flex-row gap-4">
                                            {/* Front of ID */}
                                            <div className="border-2 border-gray-300 p-4 rounded-lg bg-gray-100" style={{ width: `${frontInfo.cardWidth}px`, height: `${frontInfo.cardHeight}px` }}>
                                                <div className="text-center font-bold text-lg mb-4">CORDOVA PUBLIC COLLEGE</div>
                                                <div className="flex justify-between items-start mb-4">
                                                    {frontInfo.photo ? (
                                                        <img src={frontInfo.photo} alt="Student" className="w-24 h-32 object-cover" />
                                                    ) : (
                                                        <img src={defaultProfilePic} alt="Default Profile" className="w-24 h-32 object-cover" />
                                                    )}
                                                    <div className="text-right flex flex-col items-center"> {/* Changed to flex column and centered */}
                                                        <img src="/images/CPC.png" alt="School Logo" className="w-16 h-16 mb-2" />
                                                        <div className="text-sm font-semibold -ml-0"> {/* Added negative left margin */}
                                                            {frontInfo.academicTrack || 'BSIT-ID'}
                                                        </div>
                                                    </div>
                                                </div>
                                                <div className="text-center mb-2">
                                                    <div className="font-bold">{`${frontInfo.firstName} ${frontInfo.lastName}`}</div>
                                                    <div className="text-sm">Student name</div>
                                                </div>
                                                <div className="text-center mb-4">
                                                    <div className="font-bold">{frontInfo.idNumber}</div>
                                                    <div className="text-sm">ID number</div>
                                                </div>
                                                {frontInfo.signature ? (
                                                    <div className="text-center">
                                                        <img src={frontInfo.signature} alt="Signature" className="h-12 mx-auto" />
                                                        <div className="text-sm">Student Signature Photo</div>
                                                    </div>
                                                ) : (
                                                    <div className="h-12 bg-gray-300 flex items-center justify-center text-gray-500 text-sm">No Signature</div>
                                                )}
                                            </div>

                                            {/* Back of ID */}
                                            <div className="border-2 border-gray-300 p-4 rounded-lg bg-gray-100" style={{ width: `${frontInfo.cardWidth}px`, height: `${frontInfo.cardHeight}px` }}>
                                                <h3 className="font-bold mb-2 text-center">IN CASE OF EMERGENCY CONTACT</h3>
                                                <div className="mb-1"><span className="font-semibold">Name:</span> {backInfo.name}</div>
                                                <div className="mb-1"><span className="font-semibold">Address:</span> {backInfo.address}</div>
                                                <div className="mb-4"><span className="font-semibold">Tel No:</span> {backInfo.telNo}</div>
                                                
                                                {/* In the ID Preview section, replace the QR code placeholder with: */}
                                                <div className="w-32 h-32 mx-auto">
                                                    <QRCodeSVG 
                                                        value={`${backInfo.name},${backInfo.address},${backInfo.telNo}`}
                                                        size={128}
                                                        level="H"
                                                    />
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
};

export default IdMaker;
