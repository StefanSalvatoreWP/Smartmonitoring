import React from 'react';

const MessageBubble = ({ message, isVisible }) => {
  return (
    <div className={`message-bubble ${isVisible ? 'visible' : ''}`}>
      {message}
    </div>
  );
};

export default MessageBubble;
