import '../css/app.css';

import { createRoot } from 'react-dom/client';
import { createInertiaApp } from '@inertiajs/react';
import { resolvePageComponent } from 'laravel-vite-plugin/inertia-helpers';
import { ColorProvider } from '@/Context/ColorContext';  // Import ColorProvider

import { Ziggy } from './ziggy';

const appName = window.document.getElementsByTagName('title')[0]?.innerText || 'Laravel';

createInertiaApp({
    title: (title) => `${title} - ${appName}`,
    resolve: (name) => resolvePageComponent(`./Pages/${name}.jsx`, import.meta.glob('./Pages/**/*.jsx')),
    setup({ el, App, props }) {
        const root = createRoot(el);

        root.render(
            <ColorProvider>  {/* Wrap the App component with ColorProvider */}
                <App {...props} />
            </ColorProvider>
        );
    },
    progress: {
        color: '#4B5563',
    },
});
