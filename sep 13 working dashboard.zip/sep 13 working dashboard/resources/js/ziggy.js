import { route } from 'ziggy-js';

// The Ziggy object is now globally available, so we don't need to import it
const { Ziggy } = window;

export { Ziggy, route };
