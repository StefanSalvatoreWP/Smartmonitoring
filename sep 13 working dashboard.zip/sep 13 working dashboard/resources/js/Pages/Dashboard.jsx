import React, { useState, useEffect } from 'react';
import { Link } from '@inertiajs/react';
import { route } from '@/ziggy'; // Ensure the correct path
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout'; // Adjust path if needed
import { Head } from '@inertiajs/react';
import LoadingSpinner from '@/Components/LoadingSpinner';
import { FaUsers, FaUserGraduate, FaChalkboardTeacher, FaBook, FaCalendarAlt } from 'react-icons/fa';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Pie } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend);

const StatCard = ({ title, value, icon }) => (
    <div className="bg-white p-6 rounded-lg shadow-md">
        <div className="flex items-center justify-between">
            <div>
                <p className="text-gray-500 text-sm font-medium uppercase">{title}</p>
                <p className="mt-1 text-3xl font-semibold text-gray-900">{value}</p>
            </div>
            <div className="text-3xl text-blue-500">{icon}</div>
        </div>
    </div>
);

const Dashboard = ({ auth }) => {
    const [stats, setStats] = useState({
        totalStudents: 0,
        totalUsers: 0,
        totalSections: 0,
        totalEnrolledStudents: 0,
        studentsByGrade: {},
        recentEnrollments: [],
    });
    const [isLoading, setIsLoading] = useState(true);

    useEffect(() => {
        const fetchStats = async () => {
            try {
                const response = await fetch('/api/dashboard-stats');
                if (!response.ok) {
                    throw new Error(`HTTP error! status: ${response.status}`);
                }
                const data = await response.json();
                setStats(data);
            } catch (error) {
                console.error('Error fetching dashboard stats:', error);
            } finally {
                setIsLoading(false);
            }
        };

        fetchStats();
    }, []);

    const pieChartData = {
        labels: Object.keys(stats.studentsByGrade),
        datasets: [
            {
                data: Object.values(stats.studentsByGrade),
                backgroundColor: [
                    '#FF6384',
                    '#36A2EB',
                    '#FFCE56',
                    '#4BC0C0',
                    '#9966FF',
                    '#FF9F40',
                ],
            },
        ],
    };

    if (isLoading) {
        return <LoadingSpinner />;
    }

    return (
        <AuthenticatedLayout user={auth.user}>
            <Head title="Dashboard" />
            <div className="py-12">
                <div className="max-w-7xl mx-auto sm:px-6 lg:px-8">
                    <h1 className="text-3xl font-semibold text-gray-900 mb-6">Dashboard</h1>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                        <StatCard title="Total Students" value={stats.totalStudents} icon={<FaUserGraduate />} />
                        <StatCard title="Total Users" value={stats.totalUsers} icon={<FaUsers />} />
                        <StatCard title="Total Sections" value={stats.totalSections} icon={<FaBook />} />
                        <StatCard title="Enrolled Students" value={stats.totalEnrolledStudents} icon={<FaCalendarAlt />} />
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div className="bg-white p-6 rounded-lg shadow-md">
                            <h2 className="text-xl font-semibold mb-4">Students by Grade</h2>
                            <div className="w-full h-64">
                                <Pie data={pieChartData} options={{ maintainAspectRatio: false }} />
                            </div>
                        </div>
                        
                        <div className="bg-white p-6 rounded-lg shadow-md">
                            <h2 className="text-xl font-semibold mb-4">Recent Enrollments</h2>
                            <ul className="space-y-2">
                                {stats.recentEnrollments.map((enrollment, index) => (
                                    <li key={index} className="flex justify-between items-center">
                                        <span>{enrollment.studentName} - {enrollment.sectionName}</span>
                                        <span className="text-sm text-gray-500">{enrollment.date}</span>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
};

export default Dashboard;
