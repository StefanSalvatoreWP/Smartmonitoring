export default function ApplicationLogo({ className }) {
    return (
        <div className={`flex items-center ${className}`}>
            {/* <span className="text-2xl font-bold text-gray-800">Dashboard</span> */}
        </div>
    );
}
