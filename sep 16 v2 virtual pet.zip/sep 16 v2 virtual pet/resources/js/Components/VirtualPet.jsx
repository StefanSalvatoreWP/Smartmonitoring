import React, { useState, useRef, useEffect } from 'react';
import { usePopper } from 'react-popper';

const VirtualPet = () => {
  const [position, setPosition] = useState({ x: window.innerWidth - 100, y: window.innerHeight - 100 });
  const [isVisible, setIsVisible] = useState(true);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isChatboxOpen, setIsChatboxOpen] = useState(false);
  const [referenceElement, setReferenceElement] = useState(null);
  const [popperElement, setPopperElement] = useState(null);
  const [size, setSize] = useState(80);
  const [opacity, setOpacity] = useState(100);
  const [isStrolling, setIsStrolling] = useState(false);
  const [strollingTimer, setStrollingTimer] = useState(null);
  const [canCheckCorners, setCanCheckCorners] = useState(false);
  const [doubleClickAction, setDoubleClickAction] = useState('quickAccess');
  const [doubleClickDelay, setDoubleClickDelay] = useState(3);
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const petRef = useRef(null);
  const [direction, setDirection] = useState({ x: 1, y: 1 });
  const walkingSpeed = 1; // pixels per frame
  const changeDirectionChance = 0.005; // 0.5% chance to change direction each frame
  const edgeBuffer = 20; // pixels to keep away from the edge
  const [showMessage, setShowMessage] = useState(false);
  const [message, setMessage] = useState('');
  const [lastDirectionChange, setLastDirectionChange] = useState(0);
  const directionChangeThreshold = 5; // Number of direction changes before bouncing
  const bounceTimeout = useRef(null);

  const { styles, attributes } = usePopper(referenceElement, popperElement, {
    placement: 'left-start',
  });

  useEffect(() => {
    const handleKeyPress = (event) => {
      // Check for CTRL + L to show the pet
      if (event.ctrlKey && event.key === 'l') {
        event.preventDefault(); // Prevent default browser behavior
        setIsVisible(true);
      }
      // Check for CTRL + P to hide the pet
      if (event.ctrlKey && event.key === 'p') {
        event.preventDefault(); // Prevent default browser behavior
        setIsVisible(false);
      }
    };

    // Add the event listener
    document.addEventListener('keydown', handleKeyPress);

    // Clean up the event listener on component unmount
    return () => {
      document.removeEventListener('keydown', handleKeyPress);
    };
  }, []); // Empty dependency array means this effect runs once on mount and clean up on unmount

  useEffect(() => {
    console.log('Strolling state changed:', isStrolling);
    let animationFrameId;

    const walk = () => {
      if (isVisible && isStrolling) {
        console.log('Walking...');
        setPosition(prevPos => {
          let newX = prevPos.x + direction.x * walkingSpeed;
          let newY = prevPos.y + direction.y * walkingSpeed;

          // Check if near edges
          const isNearEdgeX = newX <= edgeBuffer || newX >= window.innerWidth - size - edgeBuffer;
          const isNearEdgeY = newY <= edgeBuffer || newY >= window.innerHeight - size - edgeBuffer;

          if (isNearEdgeX || isNearEdgeY) {
            setLastDirectionChange(prev => prev + 1);
            
            if (lastDirectionChange >= directionChangeThreshold) {
              // Bounce to a new random position
              if (!bounceTimeout.current) {
                bounceTimeout.current = setTimeout(() => {
                  const newX = Math.random() * (window.innerWidth - size - 2 * edgeBuffer) + edgeBuffer;
                  const newY = Math.random() * (window.innerHeight - size - 2 * edgeBuffer) + edgeBuffer;
                  setPosition({ x: newX, y: newY });
                  setLastDirectionChange(0);
                  setDirection({
                    x: Math.random() > 0.5 ? 1 : -1,
                    y: Math.random() > 0.5 ? 1 : -1
                  });
                  bounceTimeout.current = null;
                }, 100); // Small delay to prevent immediate re-triggering
              }
              return prevPos; // Don't move while preparing to bounce
            }

            // Change direction when hitting an edge
            if (isNearEdgeX) setDirection(prev => ({ ...prev, x: -prev.x }));
            if (isNearEdgeY) setDirection(prev => ({ ...prev, y: -prev.y }));
          } else {
            setLastDirectionChange(0); // Reset counter when moving normally
          }

          // Check if in a corner, but only after 30 seconds
          if (canCheckCorners) {
            const isInCorner = (
              (newX <= edgeBuffer && newY <= edgeBuffer) || // Top-left corner
              (newX <= edgeBuffer && newY >= window.innerHeight - size - edgeBuffer) || // Bottom-left corner
              (newX >= window.innerWidth - size - edgeBuffer && newY <= edgeBuffer) || // Top-right corner
              (newX >= window.innerWidth - size - edgeBuffer && newY >= window.innerHeight - size - edgeBuffer) // Bottom-right corner
            );

            if (isInCorner) {
              setIsStrolling(false);
              setMessage("I've reached a corner and stopped strolling!");
              setShowMessage(true);
              setTimeout(() => setShowMessage(false), 3000);
              return prevPos;
            }
          }

          // Ensure the pet stays within bounds
          newX = Math.max(edgeBuffer, Math.min(newX, window.innerWidth - size - edgeBuffer));
          newY = Math.max(edgeBuffer, Math.min(newY, window.innerHeight - size - edgeBuffer));

          // Randomly change direction occasionally
          if (Math.random() < changeDirectionChance) {
            setDirection({
              x: Math.random() > 0.5 ? 1 : -1,
              y: Math.random() > 0.5 ? 1 : -1
            });
          }

          return { x: newX, y: newY };
        });
      }
      animationFrameId = requestAnimationFrame(walk);
    };

    walk();

    return () => {
      cancelAnimationFrame(animationFrameId);
      if (strollingTimer) clearTimeout(strollingTimer);
      if (bounceTimeout.current) clearTimeout(bounceTimeout.current);
    };
  }, [isVisible, isStrolling, size, canCheckCorners, direction, lastDirectionChange]);

  useEffect(() => {
    const messages = [
      "Hi there!",
      "How can I help you?",
      "Need assistance?",
      "I'm here if you need me!",
      "Just hanging around!",
    ];

    const showRandomMessage = () => {
      const randomMessage = messages[Math.floor(Math.random() * messages.length)];
      setMessage(randomMessage);
      setShowMessage(true);
      setTimeout(() => setShowMessage(false), 3000); // Hide message after 3 seconds
    };

    const messageInterval = setInterval(showRandomMessage, 30000); // Show message every 30 seconds

    return () => clearInterval(messageInterval);
  }, []);

  const handleContextMenu = (e) => {
    e.preventDefault();
    setReferenceElement(petRef.current);
    setIsMenuOpen(true);
  };

  const handleMenuItemClick = (action) => {
    setIsMenuOpen(false);
    switch (action) {
      case 'settings':
        setIsSettingsOpen(true);
        break;
      case 'minimize':
        setIsVisible(false);
        break;
      case 'close':
        setIsVisible(false);
        // Additional logic for closing the app
        break;
      case 'chatbox':
        setIsChatboxOpen(true);
        break;
      case 'strolling':
        const newStrollingState = !isStrolling;
        setIsStrolling(newStrollingState);
        if (newStrollingState) {
          setCanCheckCorners(false);
          const timer = setTimeout(() => {
            setCanCheckCorners(true);
          }, 30000); // 30 seconds
          setStrollingTimer(timer);
        } else {
          if (strollingTimer) clearTimeout(strollingTimer);
          setCanCheckCorners(false);
        }
        console.log('Strolling mode toggled:', newStrollingState);
        break;
    }
  };

  const handleMouseDown = (e) => {
    if (e.button === 0) { // Left mouse button
      setIsDragging(true);
      setDragOffset({
        x: e.clientX - position.x,
        y: e.clientY - position.y,
      });
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      setIsMenuOpen(false); // Close dropdown when starting to drag
    }
  };

  const handleMouseMove = (e) => {
    if (isDragging) {
      setPosition({
        x: Math.max(0, Math.min(e.clientX - dragOffset.x, window.innerWidth - size)),
        y: Math.max(0, Math.min(e.clientY - dragOffset.y, window.innerHeight - size)),
      });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    document.removeEventListener('mousemove', handleMouseMove);
    document.removeEventListener('mouseup', handleMouseUp);
  };

  const petStyle = {
    position: 'fixed',
    left: `${position.x}px`,
    top: `${position.y}px`,
    width: `${size}px`,
    height: `${size}px`,
    opacity: opacity / 100,
    cursor: isDragging ? 'grabbing' : 'grab',
    transition: isDragging || isStrolling ? 'none' : 'all 0.3s ease',
    borderRadius: '50%',
    overflow: 'hidden',
    transform: `scaleX(${direction.x})`, // Flip the image based on direction
  };

  const messageStyle = {
    position: 'absolute',
    top: '-40px',
    left: '50%',
    transform: 'translateX(-50%)',
    backgroundColor: 'white',
    color: 'black',
    padding: '5px 10px',
    borderRadius: '15px',
    boxShadow: '0 2px 5px rgba(0,0,0,0.2)',
    opacity: showMessage ? 1 : 0,
    transition: 'opacity 0.3s ease-in-out',
    whiteSpace: 'nowrap',
    pointerEvents: 'none',
    zIndex: 1000,
  };

  return (
    <>
      {isVisible && (
        <div
          ref={petRef}
          style={petStyle}
          onContextMenu={handleContextMenu}
          onMouseDown={handleMouseDown}
        >
          <div style={messageStyle}>{message}</div>
          <img src="/images/cpclogo.jpeg" alt="Virtual Pet" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        </div>
      )}
      {isMenuOpen && (
        <div
          ref={setPopperElement}
          style={styles.popper}
          {...attributes.popper}
          className="bg-gray-800 text-white shadow-md rounded-md p-2"
        >
          <button onClick={() => handleMenuItemClick('settings')} className="block w-full text-left px-2 py-1 hover:bg-gray-700">Settings</button>
          <button onClick={() => handleMenuItemClick('minimize')} className="block w-full text-left px-2 py-1 hover:bg-gray-700">Minimize Pet</button>
          <button onClick={() => handleMenuItemClick('close')} className="block w-full text-left px-2 py-1 hover:bg-gray-700">Close App</button>
          <button onClick={() => handleMenuItemClick('chatbox')} className="block w-full text-left px-2 py-1 hover:bg-gray-700">Open Chatbox</button>
          <button onClick={() => handleMenuItemClick('strolling')} className="block w-full text-left px-2 py-1 hover:bg-gray-700">
            Strolling Mode: {isStrolling ? 'On' : 'Off'}
          </button>
        </div>
      )}
      {isSettingsOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
          <div className="bg-red-900 text-white p-6 rounded-lg w-96">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Settings</h2>
              <button onClick={() => setIsSettingsOpen(false)} className="text-white">&times;</button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block mb-1">Resize Pet</label>
                <input
                  type="range"
                  min="40"
                  max="200"
                  value={size}
                  onChange={(e) => setSize(Number(e.target.value))}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block mb-1">Opacity</label>
                <input
                  type="range"
                  min="10"
                  max="100"
                  value={opacity}
                  onChange={(e) => setOpacity(Number(e.target.value))}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block mb-1">Double-click</label>
                <div className="space-y-2">
                  <label className="flex items-center">
                    <input
                      type="radio"
                      value="quickAccess"
                      checked={doubleClickAction === 'quickAccess'}
                      onChange={(e) => setDoubleClickAction(e.target.value)}
                      className="mr-2"
                    />
                    Quick Access
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      value="hide"
                      checked={doubleClickAction === 'hide'}
                      onChange={(e) => setDoubleClickAction(e.target.value)}
                      className="mr-2"
                    />
                    Hide
                  </label>
                  <label className="flex items-center">
                    <input
                      type="radio"
                      value="random"
                      checked={doubleClickAction === 'random'}
                      onChange={(e) => setDoubleClickAction(e.target.value)}
                      className="mr-2"
                    />
                    Appear randomly
                  </label>
                </div>
                {doubleClickAction === 'quickAccess' && (
                  <div className="flex items-center mt-2">
                    <input
                      type="number"
                      value={doubleClickDelay}
                      onChange={(e) => setDoubleClickDelay(Number(e.target.value))}
                      className="w-16 mr-2 bg-gray-700 text-white"
                    />
                    <span>seconds</span>
                  </div>
                )}
              </div>
              <div>
                <label className="block mb-1">Strolling mode</label>
                <div className="flex space-x-2">
                  <button
                    onClick={() => setIsStrolling(true)}
                    className={`px-3 py-1 rounded ${isStrolling ? 'bg-red-600' : 'bg-gray-600'}`}
                  >
                    On
                  </button>
                  <button
                    onClick={() => setIsStrolling(false)}
                    className={`px-3 py-1 rounded ${!isStrolling ? 'bg-red-600' : 'bg-gray-600'}`}
                  >
                    Off
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      {isChatboxOpen && (
        <div className="fixed bottom-4 right-4 w-80 h-96 bg-white shadow-lg rounded-lg overflow-hidden flex flex-col">
          <div className="bg-red-900 text-white p-2 flex justify-between items-center">
            <h3>Chatbox</h3>
            <button onClick={() => setIsChatboxOpen(false)} className="text-white">&times;</button>
          </div>
          <div className="flex-grow overflow-y-auto p-2">
            {/* Chat messages would go here */}
          </div>
          <div className="p-2 bg-white">
            <input 
              type="text" 
              placeholder="Type a message..." 
              className="w-full p-2 border border-gray-300 rounded"
            />
          </div>
        </div>
      )}
    </>
  );
};

export default VirtualPet;
