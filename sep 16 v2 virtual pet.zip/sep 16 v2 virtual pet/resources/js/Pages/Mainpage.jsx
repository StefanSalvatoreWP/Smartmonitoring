import GuestLayout from '@/Layouts/GuestLayout';
import PrimaryButton from '@/Components/PrimaryButton';
import { Head, Link } from '@inertiajs/react';

export default function Mainpage() {
    return (
        <GuestLayout>
            <Head title="Smart Monitoring - Welcome" />

            <div className="min-h-screen w-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center p-4">
                <div className="w-full max-w-md bg-white rounded-xl shadow-2xl overflow-hidden">
                    <div className="p-8">
                        <div className="text-center">
                            <h1 className="text-3xl font-extrabold text-gray-900">
                                Welcome to <span className="text-blue-600">Smart Monitoring</span>
                            </h1>
                            <p className="mt-3 text-sm text-gray-500">
                                Empowering education through intelligent monitoring
                            </p>
                        </div>

                        <div className="mt-8 space-y-4">
                            <div className="relative group">
                                <div className="absolute -inset-0.5 bg-gradient-to-r from-pink-600 to-purple-600 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-tilt"></div>
                                <PrimaryButton className="relative w-full py-2 bg-gray-800 text-white border border-transparent rounded-md group-hover:bg-opacity-90 transition-all duration-200">
                                    <Link href={route('login')} className="w-full inline-block text-center text-sm font-semibold uppercase tracking-wider">
                                        Login as Admin
                                    </Link>
                                </PrimaryButton>
                            </div>
                            <div className="relative group">
                                <div className="absolute -inset-0.5 bg-gradient-to-r from-blue-600 to-green-600 rounded-lg blur opacity-75 group-hover:opacity-100 transition duration-1000 group-hover:duration-200 animate-tilt"></div>
                                <PrimaryButton className="relative w-full py-2 bg-gray-800 text-white border border-transparent rounded-md group-hover:bg-opacity-90 transition-all duration-200">
                                    <Link href={route('student.login')} className="w-full inline-block text-center text-sm font-semibold uppercase tracking-wider">
                                        Login as Student
                                    </Link>
                                </PrimaryButton>
                            </div>
                        </div>

                        <div className="mt-8 text-center">
                            <p className="text-xs text-gray-500">
                                New to Smart Monitoring? <a href="#" className="font-medium text-blue-600 hover:text-blue-500">Learn more about our platform</a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </GuestLayout>
    );
}

