<?php

use App\Http\Controllers\UserController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\AddStudentController;
use App\Http\Controllers\SectionController;
use App\Http\Controllers\StudentController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use Tightenco\Ziggy\Ziggy;
use App\Http\Controllers\EnrolledStudentController;
use App\Http\Controllers\StudentScheduleController;
use App\Http\Controllers\DashboardController;

// Route for the homepage (Mainpage)
Route::get('/', function () {
    return Inertia::render('Mainpage');
})->name('mainpage');

// Route for the dashboard
Route::get('/dashboard', function () {
    return Inertia::render('Dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

// Profile routes for authenticated users
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Admin routes
Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/users', [UserController::class, 'index'])->name('users.index');
    Route::get('/addstudents', function () {
        return Inertia::render('Addstudents'); // Ensure this component exists
    })->name('addstudents');
    Route::get('/students', [StudentController::class, 'index'])->name('students');
    Route::get('/settings', function () {
        return Inertia::render('Settings'); // Ensure this component exists
    })->name('settings');

    Route::get('/student/login', function () {
        return Inertia::render('StudentLogin'); // Ensure this component exists
    })->name('student.login');
    Route::get('/sections', function () {
        return Inertia::render('Sections'); // Ensure this component exists
    })->name('sections');
    
    Route::get('/students/info', [StudentController::class, 'info'])->name('students.info');
    
    Route::get('/students/info/{student_id}', [StudentController::class, 'showStudentInfo'])->name('students.show');
    
    Route::put('/students/{student_id}', [StudentController::class, 'update'])->name('students.update');
    
    Route::get('/students/{student_id}/schedule', function ($student_id) {
        return Inertia::render('StudentSchedule', [
            'student_id' => $student_id
        ]);
    })->name('students.schedule');
    Route::post('/students/{student_id}/assign', [StudentController::class, 'assignSubjects'])->name('students.assign');
    Route::get('/sections', [SectionController::class, 'index'])->name('sections.index');
    Route::get('/sections/{section_id}/subjects', [SectionController::class, 'getSubjects'])->name('sections.subjects');

    Route::get('/fetch-sections', [SectionController::class, 'fetchSections'])->name('sections.fetch');
});

// Route to serve Ziggy route list
Route::get('/ziggy', function () {
    return response()->json((new Ziggy)->toArray());
});

// Route to add students
Route::post('/students', [AddStudentController::class, 'store'])->name('students.store');

// Route for sections
Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/sections', [SectionController::class, 'index'])->name('sections');
    Route::post('/sections', [SectionController::class, 'store'])->name('sections.store');
    Route::put('/sections/{section}', [SectionController::class, 'update'])->name('sections.update');
});

// Route to test schedule functionality
Route::get('/test-schedule/{student_id}', function($student_id) {
    return "Testing schedule route for student " . $student_id;
})->name('test.schedule');

// Enrolled Student routes
Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/enrolled-students', [EnrolledStudentController::class, 'index'])->name('enrolled-students.index');
    Route::post('/enrolled-students', [EnrolledStudentController::class, 'store'])->name('enrolled-students.store');
    Route::get('/enrolled-students/{id}', [EnrolledStudentController::class, 'show'])->name('enrolled-students.show');
    Route::delete('/enrolled-students/{id}', [EnrolledStudentController::class, 'destroy'])->name('enrolled-students.destroy');
});

// Route to assign subjects
Route::post('/assign-subjects', [StudentScheduleController::class, 'assignSubjects']);

Route::get('/student-assignments/{student_id}', [StudentScheduleController::class, 'getStudentAssignments']);

// Route to fetch dashboard stats
Route::get('/api/dashboard-stats', [DashboardController::class, 'getStats'])->middleware(['auth', 'verified']);

require __DIR__.'/auth.php';
