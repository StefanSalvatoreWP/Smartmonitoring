<?php

namespace App\Http\Controllers;

use App\Models\User;
use Inertia\Inertia;
use Illuminate\Support\Facades\Log;

class UserController extends Controller
{
    public function index()
    {
        try {
            if (auth()->user()->role !== 'admin') {
                return Inertia::render('Dashboard', ['error' => 'Access denied. Admin only.']);
            }
            
            $users = User::all();
            return Inertia::render('Users', ['users' => $users]);
        } catch (\Exception $e) {
            Log::error('Error fetching users: ' . $e->getMessage());
            return response()->json(['error' => 'Internal Server Error'], 500);
        }
    }
}
