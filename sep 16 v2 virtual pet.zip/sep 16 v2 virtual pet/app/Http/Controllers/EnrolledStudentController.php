<?php

namespace App\Http\Controllers;

use App\Models\EnrolledStudent;
use App\Models\Student;
use App\Models\Section;
use Illuminate\Http\Request;
use Inertia\Inertia;

class EnrolledStudentController extends Controller
{
    public function index()
    {
        $enrolledStudents = EnrolledStudent::with(['student', 'section'])->get();
        return Inertia::render('EnrolledStudents/Index', ['enrolledStudents' => $enrolledStudents]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'student_id' => 'required|exists:students,id',
            'section_id' => 'required|exists:sections,id',
        ]);

        EnrolledStudent::create($validated);

        return redirect()->back()->with('success', 'Student enrolled successfully.');
    }

    public function show($id)
    {
        $enrolledStudent = EnrolledStudent::with(['student', 'section', 'subjects'])->findOrFail($id);
        return Inertia::render('EnrolledStudents/Show', ['enrolledStudent' => $enrolledStudent]);
    }

    public function destroy($id)
    {
        $enrolledStudent = EnrolledStudent::findOrFail($id);
        $enrolledStudent->delete();

        return redirect()->back()->with('success', 'Enrollment removed successfully.');
    }
}
